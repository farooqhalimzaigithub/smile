<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Gellary extends Model
{
    protected $table = 'gellaries';
    protected $guarded = [];

}
