<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Gellary;
use Faker\Generator as Faker;

$factory->define(Gellary::class, function (Faker $faker) {
    return [
        //
    ];
});
